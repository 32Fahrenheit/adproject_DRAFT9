package controller;

import javafx.embed.swing.SwingFXUtils;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.Dragboard;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


//zip
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.io.FileInputStream;
import java.util.zip.ZipOutputStream;

public class ImageFileHandler {

    private final ImageView imageView;
    private File selectedFile;
    public Image originalImage;
    public Image croppedImage;
    public Image processedImage;
    private String originalFilename;
    private ZoomHandler zoomHandler;
    private CropHandler cropHandler;
    //add daft6
    private ImageView selectedImageView;


    @FXML
    private Label statusLabel;
    @FXML
    private Label dropArea;
    @FXML
    private ScrollPane imageScrollPane, listimageScrollPane;
    @FXML
    private BorderPane imagePane;
    @FXML
    private Button startCropButton;
    @FXML
    private Button confirmCropButton;
    @FXML
    private Button selectButton;
    @FXML
    private Button selectAllButton;
    @FXML
    private  Button confirmSelectButton;


    private HBox imageContainer;
    @FXML
    private TextFlow filestatusTextFlow;

    private List<Image> selectedImages = new ArrayList<>();
    private List<File> ListFiles;


    public ImageFileHandler(ImageView imageView,
                            Label statusLabel,
                            Label dropArea,
                            TextFlow filestatusTextFlow,
                            BorderPane imagePane,
                            ScrollPane imageScrollPane,
                            ScrollPane listimageScrollPane,
                            Button startCropButton,
                            Button confirmCropButton,
                            Button selectButton,
                            Button selectAllButton,
                            Button confirmSelectButton,
                            HBox imageContainer,
                            CropHandler cropHandler) {

        this.imageView = imageView;
        this.statusLabel = statusLabel;
        this.dropArea = dropArea;
        this.filestatusTextFlow = filestatusTextFlow;
        this.imagePane = imagePane;
        this.imageScrollPane = imageScrollPane;
        this.listimageScrollPane = listimageScrollPane;
        this.zoomHandler = new ZoomHandler(imageView, imageScrollPane);
        this.cropHandler = cropHandler;
        this.startCropButton = startCropButton;
        this.confirmCropButton = confirmCropButton;
        this.selectAllButton = selectButton;
        this.confirmSelectButton = confirmSelectButton;
        this.selectAllButton = selectAllButton;
        this.imageContainer = imageContainer;
        this.imageContainer.setVisible(false);
        this.ListFiles = new ArrayList<>();

        imageContainer.getChildren().clear();
        setUpDragAndDrop();
    }

    // โหลดไฟล์ภาพ
    public void chooseFile() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Image File");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg"),
                new FileChooser.ExtensionFilter("ZIP Files", "*.zip")
        );

        List<File> newFiles = fileChooser.showOpenMultipleDialog(new Stage());

        if (newFiles != null && !newFiles.isEmpty()) {

            List<File> allFiles = new ArrayList<>();
            for (File file : newFiles) {
                if (file.getName().endsWith(".zip")) {
                    List<File> extractedFiles = extractImagesFromZip(file);
                    allFiles.addAll(extractedFiles);
                } else {
                    allFiles.add(file);
                }
            }
            LoadandprocessFileStatus(allFiles);

            Optional<File> firstValidFile = newFiles.stream()
                    .filter(file -> checkImageInFileList(file.getName()))
                    .findFirst();

            // หากมีไฟล์ที่ถูกต้อง ให้ทำการแสดงผล
            if (firstValidFile.isPresent()) {
                this.selectedFile = firstValidFile.get();
                originalImage = new Image(selectedFile.toURI().toString());
                imageView.setImage(originalImage);
                originalFilename = selectedFile.getName();
                statusLabel.setText("File loaded: " + originalFilename);
                statusLabel.setStyle("-fx-text-fill: green;");

                cropHandler.resetCroppedImage();
                startCropButton.setDisable(false);
                confirmCropButton.setDisable(false);
                zoomHandler.resetZoom();  // Reset zoom when a new image is loaded
                imagePane.minWidthProperty().bind(imageScrollPane.widthProperty());
                imagePane.minHeightProperty().bind(imageScrollPane.heightProperty());
            }
        } else {
            statusLabel.setText("File selection cancelled.");
            statusLabel.setStyle("-fx-text-fill: red;");
        }
    }

    private void setUpDragAndDrop() {
        dropArea.setOnDragOver(event -> {
            if (event.getGestureSource() != dropArea && event.getDragboard().hasFiles()) {
                event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
            }
            event.consume();
        });

        dropArea.setOnDragDropped(event -> {
            Dragboard db = event.getDragboard();
            if (db.hasFiles()) {
                List<File> dropFiles = db.getFiles();
                List<File> allFiles = new ArrayList<>();

                for (File file : dropFiles) {
                    if (file.getName().endsWith(".zip")) {
                        List<File> extractedFiles = extractImagesFromZip(file);
                        allFiles.addAll(extractedFiles);
                    } else {
                        allFiles.add(file);
                    }
                }

                LoadandprocessFileStatus(allFiles);

                Optional<File> firstValidFile = dropFiles.stream()
                        .filter(file -> checkImageInFileList(file.getName()))
                        .findFirst();

                if (firstValidFile.isPresent()) {
                    this.selectedFile = firstValidFile.get();
                    originalImage = new Image(selectedFile.toURI().toString());
                    imageView.setImage(originalImage);
                    originalFilename = selectedFile.getName();
                    statusLabel.setText("File loaded: " + originalFilename);
                    statusLabel.setStyle("-fx-text-fill: green;");

                    cropHandler.resetCroppedImage();
                    startCropButton.setDisable(false);
                    confirmCropButton.setDisable(false);
                    zoomHandler.resetZoom();  // Reset zoom when a new image is loaded
                    imagePane.minWidthProperty().bind(imageScrollPane.widthProperty());
                    imagePane.minHeightProperty().bind(imageScrollPane.heightProperty());
                }
            } else {
                statusLabel.setText("Drag and drop failed.");
                statusLabel.setStyle("-fx-text-fill: red;");
            }
            event.setDropCompleted(db.hasFiles());
            event.consume();
        });
    }

    private void LoadandprocessFileStatus(List<File> imageFiles) {
        List<String> fileStatusList = new ArrayList<>();

        for (File imageFile : imageFiles) {
            String truncatedFileName = truncateFileName(imageFile.getName(), 30);

            if (checkImageInFileList(imageFile.getName())) {
                addImage(imageFile); // Add to ScorllPane Image View//
                ListFiles.add(imageFile); // Add to List Of Files
                fileStatusList.add("Upload New File: " + truncatedFileName); // เพิ่มข้อความไฟล์ใหม่
            } else {
                fileStatusList.add("File Already Exists: " +truncatedFileName); // เพิ่มข้อความไฟล์ที่มีอยู่แล้ว
            }
        }
        // อัพเดทข้อความใน TextFlow และตั้งค่าสีตามประเภทของไฟล์
        updateStatusLabel(fileStatusList);
    }

    public void addImage(File imageFile) {
        // Create Image from file
        Image image = new Image(imageFile.toURI().toString());

        // Create ImageView to display the image
        ImageView imageView = new ImageView(image);
        imageView.setFitHeight(170);
        imageView.setFitWidth(170);
        imageView.setPreserveRatio(true);
        imageView.setSmooth(true);

        // Create Checkbox for selection
        CheckBox checkBox = new CheckBox();
        checkBox.setVisible(false); // Initially hidden, shown when 'Select' is clicked

        Tooltip tooltip = new Tooltip(imageFile.getName());
        Tooltip.install(imageView, tooltip);

        HBox imageBoxWithLabel = new HBox();
        imageBoxWithLabel.setSpacing(10);
        imageBoxWithLabel.getChildren().addAll(imageView, checkBox); // Add the checkbox next to the image

        imageContainer.getChildren().add(imageBoxWithLabel);

        // Add a click event on the image
        imageView.setOnMouseClicked(event -> {
            if (event.getClickCount() == 2) {
                ImageClicked(image, imageFile);
            }
        });

        if (!imageContainer.isVisible()) {
            imageContainer.setVisible(true);
        }
    }
    @FXML
    public void selectImages() {
        // Enable checkboxes for each image
        for (Node node : imageContainer.getChildren()) {
            if (node instanceof HBox) {
                HBox hbox = (HBox) node;
                for (Node child : hbox.getChildren()) {
                    if (child instanceof CheckBox) {
                        CheckBox checkBox = (CheckBox) child;
                        checkBox.setVisible(true); // Show checkbox
                    }
                }
            }
        }
        confirmSelectButton.setDisable(false); // Enable the Confirm Select button
    }

    @FXML
    public void selectAllImages() {
        // Select all checkboxes
        for (Node node : imageContainer.getChildren()) {
            if (node instanceof HBox) {
                HBox hbox = (HBox) node;
                for (Node child : hbox.getChildren()) {
                    if (child instanceof CheckBox) {
                        CheckBox checkBox = (CheckBox) child;
                        checkBox.setVisible(true);
                        checkBox.setSelected(true); // Select all checkboxes
                    }
                }
            }
        }
        confirmSelectButton.setDisable(false);
    }
    @FXML
    public void confirmSelect() {
        selectedImages.clear(); // Clear previously selected images before adding new ones

        for (Node node : imageContainer.getChildren()) {
            if (node instanceof HBox) {
                HBox hbox = (HBox) node;
                ImageView imageView = null;
                CheckBox checkBox = null;

                for (Node child : hbox.getChildren()) {
                    if (child instanceof ImageView) {
                        imageView = (ImageView) child;
                    } else if (child instanceof CheckBox) {
                        checkBox = (CheckBox) child;
                    }
                }

                if (checkBox != null && checkBox.isSelected() && imageView != null) {
                    selectedImages.add(imageView.getImage());
                }

                // Hide checkboxes after confirming selection
                if (checkBox != null) {
                    checkBox.setVisible(false);
                    checkBox.setSelected(false); // Optionally uncheck the checkbox for future selections
                }
            }
        }

        // Update status label
        if (!selectedImages.isEmpty()) {
            imageView.setImage(selectedImages.get(0)); // Show the first selected image for now
            statusLabel.setText(selectedImages.size() + " images selected for processing.");
            statusLabel.setStyle("-fx-text-fill: green;");
        } else {
            statusLabel.setText("No images selected.");
            statusLabel.setStyle("-fx-text-fill: red;");
        }

        confirmSelectButton.setDisable(true); // Disable the Confirm Select button after processing
    }

    public List<Image> getSelectedImages() {
        return selectedImages;
    }

    public boolean checkImageInFileList(String fileName) {

        if (this.ListFiles == null || this.ListFiles.isEmpty()) {
            return true;
        }
        for (File imageFile : this.ListFiles) {
            if (imageFile.getName().equals(fileName)) {
                return false;
            }
        }
        return true;
    }

    // บันทึกภาพ
    public void saveImage(Image imageToSave) {
        if (imageToSave == null) {
            statusLabel.setText("No image to save.");
            statusLabel.setStyle("-fx-text-fill: red;");
            return;
        }
        if (selectedFile == null) {
            statusLabel.setText("No file selected to save.");
            statusLabel.setStyle("-fx-text-fill: red;");
            return;
        }

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Image");
        if (originalFilename != null && !originalFilename.isEmpty()) {
            String fileNameWithoutExtension = generateNewFileName(selectedFile);
            fileChooser.setInitialFileName(fileNameWithoutExtension);
        }
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PNG Files", "*.png"));
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("JPG Files", "*.jpg"));
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("ZIP Files", "*.zip"));
        File saveFile = fileChooser.showSaveDialog(new Stage());

        if (saveFile != null) {
            try {
                BufferedImage bufferedImage = SwingFXUtils.fromFXImage(imageToSave, null);
                ImageIO.write(bufferedImage, "png", saveFile);
                statusLabel.setText("Image saved successfully.");
                statusLabel.setStyle("-fx-text-fill: green;");
            } catch (IOException e) {
                e.printStackTrace();
                statusLabel.setText("Failed to save image.");
                statusLabel.setStyle("-fx-text-fill: red;");
            }
        }
    }

    //แยกไฟล์มาจาก zip
    private List<File> extractImagesFromZip(File zipFile) {
        List<File> extractedImages = new ArrayList<>();
        String tempDir = System.getProperty("java.io.tmpdir"); // Use the system temp directory

        try (ZipInputStream zipInputStream = new ZipInputStream(new FileInputStream(zipFile))) {
            ZipEntry entry;
            while ((entry = zipInputStream.getNextEntry()) != null) {
                // Skip hidden/system files and non-image files
                if (entry.getName().startsWith("__MACOSX") || entry.getName().startsWith("._") ||
                        !(entry.getName().endsWith(".png") || entry.getName().endsWith(".jpg") || entry.getName().endsWith(".jpeg"))) {
                    continue; // Skip this entry
                }

                // Create the file path in the temp directory
                File extractedFile = new File(tempDir, entry.getName());
                // Ensure the directory structure exists
                extractedFile.getParentFile().mkdirs();

                try (FileOutputStream fileOutputStream = new FileOutputStream(extractedFile)) {
                    byte[] buffer = new byte[1024];
                    int length;
                    while ((length = zipInputStream.read(buffer)) > 0) {
                        fileOutputStream.write(buffer, 0, length);
                    }
                }
                extractedImages.add(extractedFile);
            }
        } catch (IOException e) {
            e.printStackTrace();
            statusLabel.setText("Failed to extract images from ZIP file.");
            statusLabel.setStyle("-fx-text-fill: red;");
        }
        return extractedImages;
    }

    // คืนค่าเป็นภาพต้นฉบับ
    @FXML
    public void onRevertToOriginal() {
        if (originalImage != null) {
            imageView.setImage(originalImage);  // คืนค่าเป็นภาพต้นฉบับ
            croppedImage = null;  // ล้างข้อมูลภาพที่ถูกครอบ
            processedImage = null;  // ล้างข้อมูลภาพที่ถูกประมวลผล
            statusLabel.setText("Reverted to original image.");
            statusLabel.setStyle("-fx-text-fill: green;");
            zoomHandler.resetZoom();
        } else {
            statusLabel.setText("No original image to revert to.");
            statusLabel.setStyle("-fx-text-fill: red;");
        }
    }

    // สร้างชื่อไฟล์ใหม่เมื่อทำการบันทึก
    private String generateNewFileName(File originalFile) {
        String originalFileName = originalFile.getName();
        String baseName = originalFileName.substring(0, originalFileName.lastIndexOf('.')); // ชื่อไฟล์ไม่รวมสกุลไฟล์
        String extension = originalFileName.substring(originalFileName.lastIndexOf('.')); // นามสกุลไฟล์

        String newFileName = baseName + "1" + extension;
        int counter = 1;

        while (new File(originalFile.getParent(), newFileName).exists()) {
            counter++;
            newFileName = baseName + counter + extension;
        }

        return newFileName;
    }

    private String truncateFileName(String fileName, int maxLength) {
        // ตรวจสอบความยาวของชื่อไฟล์ ถ้าเกิน maxLength จะตัดและเพิ่ม "..." ที่ท้าย
        if (fileName.length() > maxLength) {
            return fileName.substring(0, maxLength - 3) + "...";
        } else {
            return fileName;
        }
    }

    public Image getOriginalImage() {
        return originalImage;
    }
    public void clearSelectedImageList(){
        this.selectedImages.clear();
        this.selectedImages = null;
    }

    public void ImageClicked(Image image, File imageFile) {
        cropHandler.resetCroppedImage();
        this.originalImage = image;
        this.imageView.setImage(originalImage);
        this.selectedFile = imageFile;
        this.originalFilename = imageFile.getName();
        onRevertToOriginal();
        statusLabel.setText("Selecting Image: " + imageFile.getName());
        statusLabel.setStyle("-fx-text-fill: green;");
        filestatusTextFlow.getChildren().clear();

        startCropButton.setDisable(false);
        confirmCropButton.setDisable(false);
        imagePane.minWidthProperty().bind(imageScrollPane.widthProperty());
        imagePane.minHeightProperty().bind(imageScrollPane.heightProperty());
    }

    private void updateStatusLabel(List<String> statusMessages) {
        filestatusTextFlow.getChildren().clear(); // เคลียร์ข้อความก่อนหน้า

        for (String message : statusMessages) {
            Text text = new Text(message + "\n"); // สร้างข้อความใหม่สำหรับแต่ละสถานะ
            if (message.startsWith("Upload New File:")) {
                text.setStyle("-fx-fill: green;"); // ตั้งค่าสีเขียวสำหรับข้อความที่โหลดไฟล์ใหม่
            } else {
                text.setStyle("-fx-fill: red;"); // ตั้งค่าสีแดงสำหรับข้อความที่มีอยู่แล้ว
            }
            filestatusTextFlow.getChildren().add(text); // เพิ่มข้อความลงใน TextFlow
        }
    }


    // new save kub
    public void saveAllImagesAsZip(List<Image> images) {
        if (images == null || images.isEmpty()) {
            statusLabel.setText("No images to save.");
            statusLabel.setStyle("-fx-text-fill: red;");
            return;
        }

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Images as ZIP");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("ZIP Files", "*.zip"));
        File zipFile = fileChooser.showSaveDialog(new Stage());

        if (zipFile != null) {
            try (ZipOutputStream zipOutputStream = new ZipOutputStream(new FileOutputStream(zipFile))) {
                for (int i = 0; i < images.size(); i++) {
                    // สร้างชื่อไฟล์สำหรับแต่ละภาพใน ZIP
                    String fileName = "image_" + (i + 1) + ".png";
                    // เขียนภาพลงใน Output Stream
                    BufferedImage bufferedImage = SwingFXUtils.fromFXImage(images.get(i), null);
                    ZipEntry zipEntry = new ZipEntry(fileName);
                    zipOutputStream.putNextEntry(zipEntry);
                    ImageIO.write(bufferedImage, "png", zipOutputStream);
                    zipOutputStream.closeEntry();
                }
                statusLabel.setText("All images saved as ZIP successfully.");
                statusLabel.setStyle("-fx-text-fill: green;");
            } catch (IOException e) {
                e.printStackTrace();
                statusLabel.setText("Failed to save images as ZIP.");
                statusLabel.setStyle("-fx-text-fill: red;");
            }
        }
    }




}
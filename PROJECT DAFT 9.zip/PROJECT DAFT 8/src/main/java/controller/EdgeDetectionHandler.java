package controller;

import javafx.embed.swing.SwingFXUtils;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import model.edgedetector.detectors.CannyEdgeDetector;
import model.edgedetector.detectors.EdgeDetector;
import model.edgedetector.util.Grayscale;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EdgeDetectionHandler {

    private final ImageView imageView;
    private Image processedImage;
    private List<Image> ImageListDetected = new ArrayList<Image>();
    private ComboBox<String> algorithmChoice;
    private final Map<String, Class<? extends EdgeDetector>> edgeAlgorithms = new HashMap<>();
    private final Label statusLabel;

    public EdgeDetectionHandler(
            ImageView imageView,
            Label statusLabel,
            ComboBox<String> algorithmChoice,
            Map<String, Class<? extends EdgeDetector>> edgeAlgorithms) {
        this.imageView = imageView;
        this.statusLabel = statusLabel;
        this.algorithmChoice = algorithmChoice;
        this.edgeAlgorithms.putAll(edgeAlgorithms);
        initializeEdgeAlgorithms();
    }

    private void initializeEdgeAlgorithms() {
        edgeAlgorithms.put("Canny", model.edgedetector.detectors.CannyEdgeDetector.class);
        edgeAlgorithms.put("Sobel", model.edgedetector.detectors.SobelEdgeDetector.class);
        edgeAlgorithms.put("Laplacian", model.edgedetector.detectors.LaplacianEdgeDetector.class);
        edgeAlgorithms.put("Prewitt", model.edgedetector.detectors.PrewittEdgeDetector.class);
        edgeAlgorithms.put("Roberts Cross", model.edgedetector.detectors.RobertsCrossEdgeDetector.class);
        edgeAlgorithms.put("Gaussian", model.edgedetector.detectors.GaussianEdgeDetector.class);

        algorithmChoice.getItems().addAll(edgeAlgorithms.keySet());
        algorithmChoice.setPromptText("Select Edge Detection Algorithm");
    }

    public void ListDetectEdges(String selectedAlgorithm, List<Image> listDetect,Object... params){
        if (listDetect == null || listDetect.isEmpty()) {
            setStatus("Please load images first.", "red");
            return;
        }

        if (selectedAlgorithm == null) {
            setStatus("Please select an edge detection algorithm.", "red");
            return;
        }

        try {
            Class<? extends EdgeDetector> detectorClass = edgeAlgorithms.get(selectedAlgorithm);
            EdgeDetector detector = null;
            for (int i = 0; i < listDetect.size(); i++) {
                Image imageToProcess = listDetect.get(i);
                BufferedImage bufferedImage = SwingFXUtils.fromFXImage(imageToProcess, null);

                switch (selectedAlgorithm) {
                    case "Canny":
                        handleCannyEdgeDetection(params, bufferedImage);
                        break;

                    case "Roberts Cross":
                        double strength = (double) params[0];
                        detector = new model.edgedetector.detectors.RobertsCrossEdgeDetector(strength);
                        break;

                    case "Laplacian":
                        String maskSize = (String) params[0];
                        int maskSizeInt = Integer.parseInt(maskSize.split("x")[0]);
                        detector = new model.edgedetector.detectors.LaplacianEdgeDetector(maskSizeInt);
                        break;

                    case "Sobel":
                        int sobelKernelSize = (int) params[0];
                        int sobelThreshold = (int) params[1];
                        detector = new model.edgedetector.detectors.SobelEdgeDetector(sobelKernelSize, sobelThreshold);
                        break;

                    case "Prewitt":
                        int prewittKernelSize = (int) params[0];
                        int prewittThreshold = (int) params[1];
                        detector = new model.edgedetector.detectors.PrewittEdgeDetector(prewittKernelSize, prewittThreshold);
                        break;

                    case "Gaussian":
                        double sigma = (double) params[0];
                        int kernelSize = (int) params[1];
                        detector = new model.edgedetector.detectors.GaussianEdgeDetector(sigma, kernelSize);
                        break;

                    default:
                        detector = detectorClass.getDeclaredConstructor().newInstance();
                        break;
                }

                // Process the image with the chosen edge detector
                BufferedImage processedImage = processImageWithDetector(bufferedImage, detector);

                // Convert the processed BufferedImage back to JavaFX Image and update the list
                Image fxImage = SwingFXUtils.toFXImage(processedImage, null);
                ImageListDetected.add(fxImage);
            }

            setStatus("Edge detection completed successfully.", "green");
        } catch (NumberFormatException e) {
            setStatus("Invalid mask size. Please enter a valid number.", "red");
        } catch (Exception e) {
            e.printStackTrace();
            setStatus("Edge detection failed.", "red");
        }
    }

    public List<Image> getImageListDetected (){
        return ImageListDetected;
    }

    //Method ในการรับ BuffereedImage เพื่อส่งไป detector แล้ว return กลับมา
    private BufferedImage processImageWithDetector(BufferedImage bufferedImage, EdgeDetector detector) throws Exception {
        if (detector != null) {
            // Create a temporary file to store the input image
            File tempImageFile = new File("temp_image.png");
            ImageIO.write(bufferedImage, "png", tempImageFile);

            // Use the edge detector to process the image
            File resultFile = detector.detectEdges(tempImageFile);

            // Read the processed image back as BufferedImage
            BufferedImage processedBufferedImage = ImageIO.read(resultFile);

            // Return the processed BufferedImage to be used in the ListDetectEdges method
            return processedBufferedImage;
        }

        // Return the original image if no detector was applied
        return bufferedImage;
    }

    // Method to handle Canny edge detection with parameter checks
    private void handleCannyEdgeDetection(Object[] params, BufferedImage bufferedImage) throws Exception {
        int lowThreshold = (int) params[0];
        int highThreshold = (int) params[1];

        // Check parameters for CannyEdgeDetector
        if (lowThreshold < 0) lowThreshold = 0;
        if (highThreshold > 255) highThreshold = 255;
        if (lowThreshold > highThreshold) {
            setStatus("Low threshold cannot be greater than high threshold.", "red");
            return  ;
        }


            int[][] pixels = Grayscale.imgToGrayPixels(bufferedImage);
            EdgeDetector detector = new CannyEdgeDetector.Builder(pixels)
                    .thresholds(lowThreshold, highThreshold)
                    .L1norm(false)
                    .minEdgeSize(10)
                    .build();
            processImageWithDetector(bufferedImage, detector);
    }

    // Helper method to set status label with color
    private void setStatus(String message, String color) {
        statusLabel.setText(message);
        statusLabel.setStyle("-fx-text-fill: " + color + ";");
    }
}
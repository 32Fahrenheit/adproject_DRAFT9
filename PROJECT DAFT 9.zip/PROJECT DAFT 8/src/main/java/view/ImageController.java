package view;

import controller.CropHandler;
import controller.EdgeDetectionHandler;
import controller.ImageFileHandler;
import controller.ZoomHandler;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.TextFlow;
import model.edgedetector.detectors.EdgeDetector;
import javafx.fxml.FXML;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ImageController {

    @FXML
    private ImageView imageView;
    @FXML
    private ComboBox<String> algorithmChoice;
    @FXML
    private Label statusLabel;
    @FXML
    private BorderPane imagePane;
    @FXML
    public ScrollPane imageScrollPane;
    @FXML
    public ScrollPane listimageScrollPane;
    @FXML
    private Label dropArea;
    @FXML
    private Button startCropButton , confirmCropButton , selectButton,selectAllButton,confirmSelectButton;
    @FXML
    private HBox imageContainer;
    @FXML
    private TextFlow fileStatus;

    private ImageFileHandler imageFileHandler;
    private CropHandler cropHandler;
    private EdgeDetectionHandler edgeDetectionHandler;
    private ZoomHandler zoomHandler;

    private final Map<String, Class<? extends EdgeDetector>> edgeAlgorithms = new HashMap<>();

    //EdgeDetect Option
    //Robert
    @FXML
    private HBox robertContainer;
    @FXML
    private Slider strengthSlider;
    @FXML
    private Label strengthValueLabel;
    //Lapicain
    @FXML
    private HBox lapicianOption;
    @FXML
    private ComboBox<String> LapicianmaskSizeComboBox;
    //Canny
    @FXML
    private VBox cannyOptions;
    @FXML
    private Slider lowThresholdSlider;
    @FXML
    private Slider highThresholdSlider;
    @FXML
    private Label lowThresholdLabel;
    @FXML
    private Label highThresholdLabel;
    //Sobel
    @FXML
    private ComboBox<String> sobelKernelSizeComboBox;
    @FXML
    private Slider sobelThresholdSlider;
    @FXML
    private Label sobelThresholdLabel;
    @FXML
    private VBox sobelOptions;
    //Prewitt
    @FXML
    private ComboBox<String> prewittKernelSizeComboBox;
    @FXML
    private Slider prewittThresholdSlider;
    @FXML
    private Label prewittThresholdLabel;
    @FXML
    private VBox prewittOptions;
    //Gaussian option
    @FXML
    private Slider gaussianSigmaSlider;
    @FXML
    private ComboBox<String> gaussianKernelSizeComboBox;
    @FXML
    private Label gaussianSigmaLabel;
    @FXML
    private VBox gaussianOptions;
    @FXML
    private HBox setDefaultOption;

    // RESULT SYSTEM
    @FXML
    private Button confirmEditButton; // ปุ่ม Confirm Edit
    @FXML
    private VBox resultContainer; // ช่องแสดงภาพผลลัพธ์
    @FXML
    private ScrollPane resultScrollPane;
    @FXML
    private Button saveAllButton;


    @FXML
    private void initialize() {

        cropHandler = new CropHandler(imageView, imagePane, imageScrollPane);
        imageFileHandler = new ImageFileHandler(imageView, statusLabel,dropArea,fileStatus,imagePane,imageScrollPane,listimageScrollPane,startCropButton,confirmCropButton,selectButton,selectAllButton,confirmSelectButton,imageContainer,cropHandler);
        edgeDetectionHandler = new EdgeDetectionHandler(imageView, statusLabel,algorithmChoice,new HashMap<>());
        zoomHandler = new ZoomHandler(imageView, imageScrollPane);
        setValueOptionAlgorithm();
        setUpbutton();

    }

    private void setUpbutton(){
//        confirmEditButton.setDisable(true);
    }

    @FXML
    public void onChooseFile() {
        imageFileHandler.chooseFile();
        cropHandler.resetCroppedImage();
    }

    @FXML
    public void onStartCrop() {
        cropHandler.startCrop();
    }

    @FXML
    public void onConfirmCrop() {
        cropHandler.confirmCrop();
        confirmEditButton.setDisable(false);

    }

    @FXML
    public void onZoomIn() {
        zoomHandler.zoomIn();
    }
    @FXML
    public void onZoomOut() {
        zoomHandler.zoomOut();
    }
    @FXML
    public void onResetZoom() {
        zoomHandler.resetZoom();
    }

    @FXML
    public void onRevertToOriginal() {  imageFileHandler.onRevertToOriginal();
        cropHandler.resetCroppedImage();
    }

    @FXML
    public void onSaveImage(){
        imageFileHandler.saveImage(imageView.getImage());
    }


    @FXML
    public void onSaveAllImage() {
        List<Image> imagesToSave = new ArrayList<>();
        for (Node node : resultContainer.getChildren()) {
            if (node instanceof VBox) {
                VBox vbox = (VBox) node;
                for (Node innerNode : vbox.getChildren()) {
                    if (innerNode instanceof ImageView) {
                        imagesToSave.add(((ImageView) innerNode).getImage());
                    }
                }
            }
        }
        imageFileHandler.saveAllImagesAsZip(imagesToSave);
    }


    @FXML
    public void onDetectEdges() {
        String selectedAlgorithm = algorithmChoice.getValue();
        Image croppedImage = cropHandler.getCroppedImage();
        Image originalImage = imageFileHandler.getOriginalImage();

        Image OrginalOrCrop = (croppedImage != null) ? croppedImage : originalImage;
        List<Image> imageListDetect = new ArrayList<>();
        imageListDetect.add(OrginalOrCrop);

        List<Image> selectedListImage = imageFileHandler.getSelectedImages();
        for (Image image:selectedListImage){
            imageListDetect.add(image);
        }


        // ตรวจสอบ Algorithm ที่เลือกและส่งค่าพารามิเตอร์ที่เหมาะสม
        if ("Sobel".equals(selectedAlgorithm)) {
            int kernelSize = "3x3".equals(sobelKernelSizeComboBox.getValue()) ? 3 : 5;
            int threshold = (int) sobelThresholdSlider.getValue();
            edgeDetectionHandler.ListDetectEdges(selectedAlgorithm, imageListDetect, kernelSize, threshold);

        } else if ("Gaussian".equals(selectedAlgorithm)) {
            double sigma = gaussianSigmaSlider.getValue();
            int kernelSize = "3x3".equals(gaussianKernelSizeComboBox.getValue()) ? 3 :
                    ("5x5".equals(gaussianKernelSizeComboBox.getValue()) ? 5 : 7);
            edgeDetectionHandler.ListDetectEdges(selectedAlgorithm, imageListDetect, sigma, kernelSize);

        } else if ("Canny".equals(selectedAlgorithm)) {
            int lowThreshold = (int) lowThresholdSlider.getValue();
            int highThreshold = (int) highThresholdSlider.getValue();
            edgeDetectionHandler.ListDetectEdges(selectedAlgorithm, imageListDetect, lowThreshold, highThreshold);

        } else if ("Roberts Cross".equals(selectedAlgorithm)) {
            double strength = strengthSlider.getValue();
            edgeDetectionHandler.ListDetectEdges(selectedAlgorithm, imageListDetect, strength);

        } else if ("Laplacian".equals(selectedAlgorithm)) {
            String maskSize = LapicianmaskSizeComboBox.getValue();
            edgeDetectionHandler.ListDetectEdges(selectedAlgorithm, imageListDetect, maskSize);

        } else if ("Prewitt".equals(selectedAlgorithm)) {
            // ใหม่: รับค่าจาก Prewitt
            int kernelSize = "3x3".equals(prewittKernelSizeComboBox.getValue()) ? 3 : 5;
            int threshold = (int) prewittThresholdSlider.getValue();
            edgeDetectionHandler.ListDetectEdges(selectedAlgorithm, imageListDetect, kernelSize, threshold);

        } else {
            edgeDetectionHandler.ListDetectEdges(selectedAlgorithm, imageListDetect);
        }

        List<Image> imageListDetected = edgeDetectionHandler.getImageListDetected();

        imageListDetected.stream().map(ImageView::new).forEach(imageView -> {
            imageView.setFitHeight(150);
            imageView.setFitWidth(150);
            imageView.setPreserveRatio(true);
            imageView.setSmooth(true);

            resultContainer.getChildren().add(imageView);
        });

//        imageFileHandler.clearSelectedImageList();
//        resultScrollPane.setContent(resultContainer);
        confirmEditButton.setDisable(false);
    }
    //Method Option EdgeDetection
    private void setValueOptionAlgorithm() {

        //gaussian
        gaussianKernelSizeComboBox.getItems().clear();
        gaussianKernelSizeComboBox.getItems().addAll("3x3", "5x5", "7x7");
        gaussianKernelSizeComboBox.setValue("5x5");
        gaussianSigmaSlider.setMin(0.5);
        gaussianSigmaSlider.setMax(5.0);
        gaussianSigmaSlider.setValue(1.4);
        gaussianSigmaLabel.setText(String.format("%.1f", gaussianSigmaSlider.getValue()));

        gaussianSigmaSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            gaussianSigmaLabel.setText(String.format("%.1f", newValue.doubleValue()));
        });

        //sobel
        sobelKernelSizeComboBox.getItems().clear();
        sobelKernelSizeComboBox.getItems().addAll("3x3", "5x5");
        sobelKernelSizeComboBox.setValue("3x3");
        sobelThresholdSlider.setMin(0);
        sobelThresholdSlider.setMax(350);
        sobelThresholdSlider.setValue(105); // Default threshold value
        sobelThresholdLabel.setText(String.format("%.0f", sobelThresholdSlider.getValue()));
        sobelThresholdSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            sobelThresholdLabel.setText(String.format("%.0f", newValue.doubleValue()));
        });


        //prewitt
        prewittKernelSizeComboBox.getItems().clear();
        prewittKernelSizeComboBox.getItems().addAll("3x3", "5x5");
        prewittKernelSizeComboBox.setValue("3x3");
        prewittThresholdSlider.setMin(0);
        prewittThresholdSlider.setMax(350);
        prewittThresholdSlider.setValue(25); // Default threshold value
        prewittThresholdLabel.setText(String.format("%.0f", prewittThresholdSlider.getValue()));

        prewittThresholdSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            prewittThresholdLabel.setText(String.format("%.0f", newValue.doubleValue()));
        });

        //Lapician
        LapicianmaskSizeComboBox.getItems().clear();
        LapicianmaskSizeComboBox.getItems().addAll("3x3", "5x5" , "7x7");
        LapicianmaskSizeComboBox.setValue("3x3");

        //Robert
        strengthSlider.setValue(4);
        strengthSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            strengthValueLabel.setText(String.format("%.0f", newValue.doubleValue()));
        });

        //Canny
        lowThresholdSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            lowThresholdLabel.setText(String.format("%.1f", newValue.doubleValue()));
        });
        highThresholdSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            highThresholdLabel.setText(String.format("%.1f", newValue.doubleValue()));
        });
        lowThresholdSlider.setMin(1);
        lowThresholdSlider.setMax(150);
        lowThresholdSlider.setValue(20);
        highThresholdSlider.setMin(1);
        highThresholdSlider.setMax(90);
        highThresholdSlider.setValue(40);
        lowThresholdLabel.setText(String.format("%.1f", lowThresholdSlider.getValue()));
        highThresholdLabel.setText(String.format("%.1f", highThresholdSlider.getValue()));


        if (algorithmChoice.getItems().isEmpty()) {
            algorithmChoice.getItems().addAll("Canny", "Sobel", "Laplacian", "Prewitt", "Roberts Cross", "Gaussian");
        }
        algorithmChoice.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            updateAlgorithmOptions(newValue);
        });

    }

    private void updateAlgorithmOptions(String algorithm) {
        robertContainer.setVisible(false);
        lapicianOption.setVisible(false);
        cannyOptions.setVisible(false);
        sobelOptions.setVisible(false);
        prewittOptions.setVisible(false);
        gaussianOptions.setVisible(false);
        setDefaultOption.setVisible(false);

        switch (algorithm) {
            case "Sobel":
                sobelOptions.setVisible(true);
                setDefaultOption.setVisible(true);
                break;
            case "Roberts Cross":
                robertContainer.setVisible(true);
                setDefaultOption.setVisible(true);
                break;
            case "Laplacian":
                lapicianOption.setVisible(true);
                setDefaultOption.setVisible(true);
                break;
            case "Canny":
                cannyOptions.setVisible(true);
                setDefaultOption.setVisible(true);
                break;
            case "Prewitt":
                prewittOptions.setVisible(true);
                setDefaultOption.setVisible(true);
                break;
            case "Gaussian":
                gaussianOptions.setVisible(true);
                setDefaultOption.setVisible(true);
                break;
            default:
                break;
        }
    }

    @FXML
    private void setDefaults() {
        // Gaussian Defaults
        gaussianKernelSizeComboBox.setValue("5x5");
        gaussianSigmaSlider.setValue(1.4);
        gaussianSigmaLabel.setText(String.format("%.1f", gaussianSigmaSlider.getValue()));

        // Sobel Defaults
        sobelKernelSizeComboBox.setValue("3x3");
        sobelThresholdSlider.setValue(105);
        sobelThresholdLabel.setText(String.format("%.0f", sobelThresholdSlider.getValue()));

        // Prewitt Defaults
        prewittKernelSizeComboBox.setValue("3x3");
        prewittThresholdSlider.setValue(25);
        prewittThresholdLabel.setText(String.format("%.0f", prewittThresholdSlider.getValue()));

        // Laplacian Defaults
        LapicianmaskSizeComboBox.setValue("3x3");

        // Roberts Cross Defaults
        strengthSlider.setValue(4);
        strengthValueLabel.setText(String.format("%.0f", strengthSlider.getValue()));

        // Canny Defaults
        lowThresholdSlider.setValue(20);
        highThresholdSlider.setValue(40);
        lowThresholdLabel.setText(String.format("%.1f", lowThresholdSlider.getValue()));
        highThresholdLabel.setText(String.format("%.1f", highThresholdSlider.getValue()));

        statusLabel.setText("Parameters reset to default values.");
        statusLabel.setStyle("-fx-text-fill: green;");
    }



    @FXML
    public void onConfirmEdit() {
        Image editedImage = imageView.getImage();
        if (editedImage != null) {
            addImageToResultContainer(editedImage);
            imageFileHandler.onRevertToOriginal(); // Reset the image view to original after confirming edit
            confirmEditButton.setDisable(true);
        } else {
            statusLabel.setText("No edited image to confirm.");
            statusLabel.setStyle("-fx-text-fill: red;");
        }
    }

    private void addImageToResultContainer(Image image) {
        ImageView resultImageView = new ImageView(image);
        resultImageView.setFitWidth(150); // กำหนดขนาดที่เหมาะสม
        resultImageView.setPreserveRatio(true);

        VBox imageBoxWithLabel = new VBox();
        imageBoxWithLabel.setSpacing(5);
        imageBoxWithLabel.getChildren().add(resultImageView);

        resultImageView.setOnMouseClicked(event -> {
            if (event.getClickCount() == 1) { // ตรวจสอบว่าคลิกครั้งเดียว
                imageView.setImage(image); // แสดงภาพที่เลือกกลับใน ImageView หลัก
                confirmEditButton.setDisable(false); // เปิดการใช้งานปุ่ม Confirm Edit
                statusLabel.setText("Image selected for further editing.");
                statusLabel.setStyle("-fx-text-fill: green;");
            }
        });

        resultContainer.getChildren().add(imageBoxWithLabel); // เพิ่ม ImageView ลงใน Result Area

        // เปิดการใช้งานปุ่ม Save All หากมีภาพใน Result Area
        saveAllButton.setDisable(resultContainer.getChildren().isEmpty());
    }

    @FXML
    private void onSelectImages() {
        imageFileHandler.selectImages();
    }

    @FXML
    private void onSelectAllImages() {
        imageFileHandler.selectAllImages();
    }

    @FXML
    private void onConfirmSelect() {
        imageFileHandler.confirmSelect();
    }

}
